//! Shared application state.
//!
//! Global state, clients, and caches will be defined here.
