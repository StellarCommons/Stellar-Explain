//! Operation domain models.
//!
//! Internal representation of Stellar operations, independent of Horizon JSON.

use crate::models::memo::Memo;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone)]
pub struct Transaction {
    pub hash: String,
    pub successful: bool,
    pub fee_charged: u64,
    pub operations: Vec<Operation>,
    pub memo: Memo,
}

/// Represents a Stellar operation.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Operation {
    Payment(PaymentOperation),
    SetOptions(SetOptionsOperation),
    Other(OtherOperation),
}

/// A payment operation that sends an asset from one account to another.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PaymentOperation {
    pub id: String,
    pub source_account: Option<String>,
    pub destination: String,
    pub asset_type: String,
    pub asset_code: Option<String>,
    pub asset_issuer: Option<String>,
    pub amount: String,
}

/// A set_options operation that configures account settings.
///
/// All fields are optional — set_options can change any subset of account
/// settings in a single operation.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
pub struct SetOptionsOperation {
    pub id: String,
    pub source_account: Option<String>,
    pub inflation_dest: Option<String>,
    pub clear_flags: Option<u32>,
    pub set_flags: Option<u32>,
    pub master_weight: Option<u32>,
    pub low_threshold: Option<u32>,
    pub med_threshold: Option<u32>,
    pub high_threshold: Option<u32>,
    pub home_domain: Option<String>,
    pub signer_key: Option<String>,
    pub signer_weight: Option<u32>,
}

/// Placeholder for operation types we do not yet explain.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct OtherOperation {
    pub id: String,
    pub operation_type: String,
}

impl Operation {
    /// Returns true if this operation is a payment.
    pub fn is_payment(&self) -> bool {
        matches!(self, Operation::Payment(_))
    }

    /// Returns true if this operation is a set_options.
    pub fn is_set_options(&self) -> bool {
        matches!(self, Operation::SetOptions(_))
    }

    /// Returns the operation ID.
    pub fn id(&self) -> &str {
        match self {
            Operation::Payment(p) => &p.id,
            Operation::SetOptions(s) => &s.id,
            Operation::Other(o) => &o.id,
        }
    }
}

use crate::services::horizon::HorizonOperation;

impl From<HorizonOperation> for Operation {
    fn from(op: HorizonOperation) -> Self {
        match op.type_i.as_str() {
            "payment" => Operation::Payment(PaymentOperation {
                id: op.id,
                source_account: op.from,
                destination: op.to.unwrap_or_default(),
                asset_type: op.asset_type.unwrap_or_else(|| "native".to_string()),
                asset_code: op.asset_code,
                asset_issuer: op.asset_issuer,
                amount: op.amount.unwrap_or_else(|| "0".to_string()),
            }),
            "set_options" => Operation::SetOptions(SetOptionsOperation {
                id: op.id,
                source_account: op.source_account,
                inflation_dest: op.inflation_dest,
                clear_flags: op.clear_flags,
                set_flags: op.set_flags,
                master_weight: op.master_weight,
                low_threshold: op.low_threshold,
                med_threshold: op.med_threshold,
                high_threshold: op.high_threshold,
                home_domain: op.home_domain,
                signer_key: op.signer_key,
                signer_weight: op.signer_weight,
            }),
            _ => Operation::Other(OtherOperation {
                id: op.id,
                operation_type: op.type_i,
            }),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_payment() {
        let payment = Operation::Payment(PaymentOperation {
            id: "12345".to_string(),
            source_account: None,
            destination: "GDEST...".to_string(),
            asset_type: "native".to_string(),
            asset_code: None,
            asset_issuer: None,
            amount: "100.0".to_string(),
        });

        let other = Operation::Other(OtherOperation {
            id: "67890".to_string(),
            operation_type: "create_account".to_string(),
        });

        assert!(payment.is_payment());
        assert!(!other.is_payment());
    }

    #[test]
    fn test_is_set_options() {
        let set_opts = Operation::SetOptions(SetOptionsOperation {
            id: "op1".to_string(),
            home_domain: Some("example.com".to_string()),
            ..Default::default()
        });

        assert!(set_opts.is_set_options());
        assert!(!set_opts.is_payment());
    }

    #[test]
    fn test_operation_id() {
        let payment = Operation::Payment(PaymentOperation {
            id: "12345".to_string(),
            source_account: None,
            destination: "GDEST...".to_string(),
            asset_type: "native".to_string(),
            asset_code: None,
            asset_issuer: None,
            amount: "100.0".to_string(),
        });

        assert_eq!(payment.id(), "12345");
    }

    #[test]
    fn test_set_options_id() {
        let op = Operation::SetOptions(SetOptionsOperation {
            id: "set-op-99".to_string(),
            ..Default::default()
        });

        assert_eq!(op.id(), "set-op-99");
    }
}